package com.shield

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var adminView: TextView
    private lateinit var passView: TextView
    private lateinit var hitsView: TextView
    private lateinit var lockView: TextView
    private lateinit var wordInput: EditText
    private lateinit var wordsBox: LinearLayout
    private lateinit var passwordBox: LinearLayout
    private lateinit var pwInput: EditText
    private lateinit var releaseBtn: Button

    private val admin: ComponentName by lazy { ComponentName(this, AdminReceiver::class.java) }
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }
    private var dp = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Guard.init(this)
        dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.setPadding(pad, (32 * dp).toInt(), pad, pad)

        t.addView(label("Щит от 18+", 24f))
        t.addView(label("Закрывает страницы с запрещёнными словами в браузерах, поиске и Telegram. У приложения нет доступа в интернет: оно ничего не отправляет и не сохраняет, что ты читаешь.", 13f))

        // ----- шаг 1 -----
        t.addView(space())
        t.addView(label("Шаг 1. Фильтр на всём телефоне (сильнее всего)", 17f))
        t.addView(label("Настройки → Сеть и интернет (или Подключение и общий доступ) → Частный DNS → «Имя хоста поставщика частного DNS». Впиши: family-filter-dns.cleanbrowsing.org и сохрани. Это блокирует сайты 18+ и включает безопасный поиск Google и Bing.", 13f))
        t.addView(button("Открыть настройки сети") { openSettings(Settings.ACTION_WIRELESS_SETTINGS) })

        // ----- шаг 2 -----
        t.addView(space())
        t.addView(label("Шаг 2. Включить слежение", 17f))
        t.addView(label("Если переключатель серый («ограниченная настройка»): «Сведения о приложении» → три точки вверху справа → «Разрешить ограниченные настройки». Потом «Специальные возможности» → «Щит от 18+» → включить.", 13f))
        t.addView(button("Сведения о приложении") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:" + packageName)
            startActivity(i)
        })
        t.addView(button("Открыть «Специальные возможности»") { openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) })
        t.addView(button("Снять ограничения батареи") { openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) })
        statusView = label("", 15f)
        t.addView(statusView)

        // ----- шаг 3 -----
        t.addView(space())
        t.addView(label("Шаг 3. Защита от удаления", 17f))
        t.addView(label("Права администратора: пока они включены, кнопка «Удалить» у приложения не работает.", 13f))
        t.addView(button("Включить защиту от удаления") {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Нужно, чтобы приложение нельзя было удалить без пароля.")
            try {
                startActivity(i)
            } catch (e: Exception) {
                toast("Не получилось открыть, включи в настройках вручную")
            }
        })
        adminView = label("", 15f)
        t.addView(adminView)

        // ----- шаг 4 -----
        t.addView(space())
        t.addView(label("Шаг 4. Пароль (16 символов и больше)", 17f))
        t.addView(label("Лучше всего, если пароль придумает и запомнит близкий человек, которому ты доверяешь, и не скажет тебе. Тогда ты не сможешь отключить защиту в слабую минуту. Если пароль потерять, снять защиту можно будет только сбросом телефона до заводских настроек.", 13f))
        t.addView(button("Задать пароль") { showSetPassword() })
        passView = label("", 15f)
        t.addView(passView)

        // ----- шаг 5 -----
        t.addView(space())
        t.addView(label("Шаг 5. Запереть", 17f))
        t.addView(label("После этого настройки приложения, Частный DNS и удаление приложения будут закрыты. Открыть их можно только по паролю.", 13f))
        t.addView(button("Запереть защиту") { askArm() })
        hitsView = label("", 14f)
        t.addView(hitsView)

        // ----- слова -----
        t.addView(space())
        t.addView(label("Слова для блокировки", 17f))
        t.addView(label("Встроенный список: " + Guard.builtinCount() + " слов и названий сайтов. Свои слова можно добавлять в любое время, а убирать только когда защита не заперта или открыто окно.", 13f))
        wordInput = EditText(this)
        wordInput.hint = "Новое слово или название сайта"
        wordInput.inputType = InputType.TYPE_CLASS_TEXT
        wordInput.setSingleLine()
        t.addView(wordInput)
        t.addView(button("Добавить слово") {
            val w = wordInput.text.toString()
            if (Guard.addWord(w)) {
                wordInput.setText("")
                renderWords()
            } else {
                toast("Не добавлено: слишком короткое или уже есть")
            }
        })
        wordsBox = LinearLayout(this)
        wordsBox.orientation = LinearLayout.VERTICAL
        t.addView(wordsBox)

        // ----- отключение -----
        t.addView(space())
        t.addView(label("Отключение", 17f))
        lockView = label("", 14f)
        t.addView(lockView)
        passwordBox = LinearLayout(this)
        passwordBox.orientation = LinearLayout.VERTICAL
        pwInput = EditText(this)
        pwInput.hint = "Пароль"
        pwInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        pwInput.setSingleLine()
        passwordBox.addView(pwInput)
        passwordBox.addView(button("Открыть окно на 10 минут") { openWithPassword() })
        t.addView(passwordBox)
        releaseBtn = button("Снять защиту полностью") { askRelease() }
        t.addView(releaseBtn)
        t.addView(space())

        val sv = ScrollView(this)
        sv.addView(t)
        setContentView(sv)
        renderWords()
    }

    // ---------- помощники ----------

    private fun label(s: String, size: Float): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size
        v.setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
        return v
    }

    private fun space(): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (14 * dp).toInt())
        return v
    }

    private fun button(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { onClick() }
        return b
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            toast("Не получилось открыть, найди это в настройках вручную")
        }
    }

    private fun dpm(): DevicePolicyManager = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val x = s % 60
        return String.format("%02d:%02d:%02d", h, m, x)
    }

    // ---------- действия ----------

    private fun showSetPassword() {
        if (Guard.passwordSet()) {
            toast("Пароль уже задан")
            return
        }
        val lay = LinearLayout(this)
        lay.orientation = LinearLayout.VERTICAL
        val p = (16 * dp).toInt()
        lay.setPadding(p, p, p, 0)
        val e1 = EditText(this)
        e1.hint = "Пароль (16 символов и больше)"
        e1.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val e2 = EditText(this)
        e2.hint = "Повтори пароль"
        e2.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        lay.addView(e1)
        lay.addView(e2)
        AlertDialog.Builder(this)
            .setTitle("Задать пароль")
            .setView(lay)
            .setPositiveButton("Сохранить") { _, _ ->
                val a = e1.text.toString()
                val b = e2.text.toString()
                if (a.length < 16) {
                    toast("Нужно минимум 16 символов")
                } else if (a != b) {
                    toast("Пароли не совпали")
                } else {
                    Guard.setPassword(a)
                    toast("Пароль задан")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun askArm() {
        if (Guard.protectOn()) {
            toast("Уже заперто")
            return
        }
        if (!Guard.passwordSet()) {
            toast("Сначала задай пароль (шаг 4)")
            return
        }
        if (!serviceOn()) {
            toast("Сначала включи слежение (шаг 2)")
            return
        }
        if (!dpm().isAdminActive(admin)) {
            toast("Сначала включи защиту от удаления (шаг 3)")
            return
        }
        AlertDialog.Builder(this)
            .setMessage("После этого настройки приложения, Частный DNS и удаление будут закрыты. Открыть их можно только по паролю. Запереть?")
            .setPositiveButton("Запереть") { _, _ ->
                Guard.armProtect(true)
                toast("Защита заперта")
            }
            .setNegativeButton("Нет", null)
            .show()
    }

    private fun openWithPassword() {
        val pw = pwInput.text.toString()
        if (Guard.openWindowWithPassword(pw)) {
            pwInput.setText("")
            toast("Окно открыто на 10 минут")
        } else {
            val wait = Guard.triesLockedMs()
            if (wait > 0L) toast("Слишком много попыток. Подожди ещё " + (wait / 60000L + 1L) + " мин")
            else toast("Пароль неверный")
        }
    }

    private fun askRelease() {
        AlertDialog.Builder(this)
            .setMessage("Снять защиту полностью? Пароль и защита от удаления будут отключены, приложение можно будет удалить.")
            .setPositiveButton("Снять") { _, _ ->
                try {
                    dpm().removeActiveAdmin(admin)
                } catch (e: Exception) {
                    // уже выключено
                }
                Guard.releaseAll()
                toast("Защита снята")
            }
            .setNegativeButton("Нет", null)
            .show()
    }

    private fun renderWords() {
        wordsBox.removeAllViews()
        val l = Guard.userWords()
        if (l.isEmpty()) wordsBox.addView(label("Своих слов пока нет.", 13f))
        for (w in l) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(label(w, 14f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Убрать") {
                if (Guard.removeWord(w)) renderWords()
                else toast("Убирать слова можно только когда защита не заперта или открыто окно")
            })
            wordsBox.addView(row)
        }
    }

    // ---------- обновление экрана ----------

    private fun refresh() {
        statusView.text = if (serviceOn()) "Слежение: ВКЛЮЧЕНО" else "Слежение: ВЫКЛЮЧЕНО. Сделай шаг 2."
        adminView.text = if (dpm().isAdminActive(admin)) "Защита от удаления: ВКЛЮЧЕНА" else "Защита от удаления: выключена"
        passView.text = if (Guard.passwordSet()) "Пароль: задан" else "Пароль: не задан"
        hitsView.text = "Заблокировано раз: " + Guard.hits()

        val on = Guard.protectOn()
        val left = Guard.windowLeft()
        val tl = Guard.triesLockedMs()
        if (!on) {
            lockView.text = "Защита ещё не заперта. Пройди шаги 1-5."
        } else if (left > 0L) {
            lockView.text = "Окно открыто ещё " + fmt(left) + ". Сейчас можно менять настройки, удалять слова и снять защиту."
        } else if (tl > 0L) {
            lockView.text = "Заперто. Слишком много неверных попыток, ввод пароля закрыт ещё " + fmt(tl)
        } else {
            lockView.text = "Заперто. Открыть можно только по паролю."
        }
        passwordBox.visibility = if (on && Guard.passwordSet()) View.VISIBLE else View.GONE
        releaseBtn.visibility = if (!on || left > 0L) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}

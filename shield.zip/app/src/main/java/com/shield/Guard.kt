package com.shield

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONArray
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Настройки защиты: слова, пауза на отключение, счётчик блокировок. Всё хранится только на телефоне. */
object Guard {
    private const val DAY = 24L * 60L * 60L * 1000L
    private const val WINDOW = 10L * 60L * 1000L
    private var prefs: SharedPreferences? = null
    @Volatile private var cache: List<String>? = null

    val watched: Set<String> = setOf(
        // браузеры и поиск
        "com.android.chrome", "com.chrome.beta", "org.mozilla.firefox", "org.mozilla.firefox_beta",
        "com.brave.browser", "com.opera.browser", "com.opera.mini.native", "com.microsoft.emmx",
        "com.sec.android.app.sbrowser", "com.android.browser", "com.mi.globalbrowser", "com.miui.browser",
        "com.yandex.browser", "ru.yandex.searchplugin", "com.google.android.googlequicksearchbox",
        "com.duckduckgo.mobile.android", "com.vivaldi.browser", "com.kiwibrowser.browser",
        "com.UCMobile.intl", "com.uc.browser.en",
        // Telegram и клиенты
        "org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus",
        "org.thunderdog.challegram", "nekox.messenger", "tw.nekomimi.nekogram"
    )

    val settingsPackages: Set<String> = setOf(
        "com.android.settings", "com.miui.securitycenter", "com.miui.packageinstaller",
        "com.google.android.packageinstaller", "com.android.packageinstaller"
    )

    // Встроенный список: названия сайтов и однозначные слова. Свои слова добавляются в приложении.
    private val builtin: List<String> = listOf(
        "порно", "порнух", "эротика", "эротическ", "хентай", "минет", "проститутк",
        "секс видео", "секс чат", "секс знакомства", "секс фото", "слитые фото", "слив фото",
        "голые девушки", "голая девушка", "обнажен",
        "18+ канал", "18+ чат", "для взрослых 18+",
        "porn", "xvideos", "xnxx", "xhamster", "pornhub", "redtube", "youporn", "brazzers",
        "onlyfans", "hentai", "nhentai", "rule34", "e-hentai", "hanime", "erome", "chaturbate",
        "stripchat", "bongacams", "livejasmin", "camsoda", "fapello", "nsfw", "futanari",
        "sex video", "sex chat", "nudes"
    )

    @Synchronized
    fun init(c: Context) {
        if (prefs == null) prefs = c.applicationContext.getSharedPreferences("shield", Context.MODE_PRIVATE)
    }

    private fun readL(k: String): Long = prefs?.getLong(k, 0L) ?: 0L
    private fun writeL(k: String, v: Long) {
        prefs?.edit()?.putLong(k, v)?.apply()
    }

    fun norm(s: String): String = s.lowercase().replace('ё', 'е')

    // ---------- слова ----------

    fun userWords(): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(prefs?.getString("words", "[]") ?: "[]")
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
            // пустой список
        }
        return out
    }

    private fun saveWords(l: List<String>) {
        val a = JSONArray()
        for (w in l) a.put(w)
        prefs?.edit()?.putString("words", a.toString())?.apply()
        cache = null
    }

    fun builtinCount(): Int = builtin.size

    private fun allWords(): List<String> {
        val c = cache
        if (c != null) return c
        val l = ArrayList<String>()
        for (w in builtin) l.add(norm(w))
        for (w in userWords()) l.add(norm(w))
        cache = l
        return l
    }

    @Synchronized
    fun addWord(w: String): Boolean {
        val x = norm(w.trim())
        if (x.length < 2) return false
        val l = ArrayList<String>(userWords())
        if (l.contains(x) || builtin.contains(x)) return false
        l.add(x)
        saveWords(l)
        return true
    }

    @Synchronized
    fun removeWord(w: String): Boolean {
        if (!editable()) return false
        val l = ArrayList<String>(userWords())
        val r = l.remove(w)
        if (r) saveWords(l)
        return r
    }

    fun match(text: String): String? {
        for (w in allWords()) {
            if (text.contains(w)) return w
        }
        return null
    }

    /** Экраны настроек, которые нельзя открывать, пока защита заперта. */
    fun settingsHit(text: String): Boolean =
        text.contains("щит от 18+") || text.contains("private dns") || text.contains("частный dns")

    // ---------- пауза на отключение ----------

    fun locked(): Boolean = System.currentTimeMillis() >= readL("openUntil")
    fun unlockAt(): Long = readL("unlockAt")

    fun requestUnlock() {
        if (passwordSet()) return
        if (unlockAt() == 0L) writeL("unlockAt", System.currentTimeMillis() + DAY)
    }

    fun cancelRequest() = writeL("unlockAt", 0L)

    fun canOpen(): Boolean {
        val u = unlockAt()
        return u != 0L && System.currentTimeMillis() >= u
    }

    fun openWindow(): Boolean {
        if (passwordSet() || !canOpen()) return false
        writeL("openUntil", System.currentTimeMillis() + WINDOW)
        writeL("unlockAt", 0L)
        return true
    }

    fun closeWindow() = writeL("openUntil", 0L)

    fun windowLeft(): Long = Math.max(0L, readL("openUntil") - System.currentTimeMillis())

    // ---------- запирание и пароль ----------

    private const val ITER = 60000

    fun protectOn(): Boolean = readL("protect") == 1L
    fun armProtect(on: Boolean) = writeL("protect", if (on) 1L else 0L)

    /** Слова можно убирать, если защита ещё не заперта или открыто окно. */
    fun editable(): Boolean = !protectOn() || !locked()

    fun passwordSet(): Boolean = (prefs?.getString("pwHash", null) ?: "").isNotEmpty()

    private fun hash(pw: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pw.toCharArray(), salt, ITER, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    @Synchronized
    fun setPassword(pw: String): Boolean {
        if (pw.length < 16 || passwordSet()) return false
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val h = hash(pw, salt)
        prefs?.edit()
            ?.putString("pwSalt", Base64.encodeToString(salt, Base64.NO_WRAP))
            ?.putString("pwHash", Base64.encodeToString(h, Base64.NO_WRAP))
            ?.apply()
        return true
    }

    /** Сколько миллисекунд ещё нельзя вводить пароль (после 5 неверных попыток пауза час). */
    fun triesLockedMs(): Long = Math.max(0L, readL("tryLockUntil") - System.currentTimeMillis())

    @Synchronized
    fun checkPassword(pw: String): Boolean {
        if (triesLockedMs() > 0L) return false
        val h = prefs?.getString("pwHash", null) ?: return false
        val s = prefs?.getString("pwSalt", null) ?: return false
        val ok = MessageDigest.isEqual(
            Base64.decode(h, Base64.NO_WRAP),
            hash(pw, Base64.decode(s, Base64.NO_WRAP))
        )
        if (ok) {
            writeL("fails", 0L)
        } else {
            val f = readL("fails") + 1L
            writeL("fails", f)
            if (f >= 5L) {
                writeL("tryLockUntil", System.currentTimeMillis() + 60L * 60L * 1000L)
                writeL("fails", 0L)
            }
        }
        return ok
    }

    fun openWindowWithPassword(pw: String): Boolean {
        if (!checkPassword(pw)) return false
        writeL("openUntil", System.currentTimeMillis() + WINDOW)
        return true
    }

    /** Полностью снять защиту (вызывается только в открытом окне). */
    @Synchronized
    fun releaseAll() {
        writeL("protect", 0L)
        writeL("unlockAt", 0L)
        writeL("openUntil", 0L)
        prefs?.edit()?.remove("pwHash")?.remove("pwSalt")?.apply()
    }

    // ---------- счётчик ----------

    fun registerHit() = writeL("hits", readL("hits") + 1L)
    fun hits(): Long = readL("hits")
}

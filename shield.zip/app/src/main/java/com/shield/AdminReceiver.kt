package com.shield

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/** Права администратора нужны только для одного: пока они включены, приложение нельзя удалить. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Щит от 18+ не даст отключить себя без пароля. Подумай ещё раз, ты сам это выбрал."
}

package com.shield

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Следит за окнами браузеров и Telegram. Нашёл запрещённое слово: возвращает назад,
 * при повторе сразу выходит на главный экран. Экраны настроек этого приложения и
 * Private DNS закрыты, пока не открыто окно отключения.
 */
class ShieldService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private var lastScan = 0L
    private var lastBlock = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Guard.init(this)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        val isSettings = Guard.settingsPackages.contains(pkg)
        if (!isSettings && !Guard.watched.contains(pkg)) return
        Guard.init(this)
        if (isSettings && (!Guard.protectOn() || !Guard.locked())) return

        val now = System.currentTimeMillis()
        if (now - lastScan < 500) return
        lastScan = now

        Guard.init(this)
        val root = rootInActiveWindow ?: return
        val text = collect(root)

        if (isSettings) {
            if (Guard.settingsHit(text)) {
                performGlobalAction(GLOBAL_ACTION_HOME)
                toast("Щит: эти настройки сейчас закрыты")
                lastScan = now + 700
            }
            return
        }
        val hit = Guard.match(text)
        if (hit != null) {
            Guard.registerHit()
            val again = now - lastBlock < 3000
            lastBlock = now
            performGlobalAction(if (again) GLOBAL_ACTION_HOME else GLOBAL_ACTION_BACK)
            toast("Щит: заблокировано")
            lastScan = now + 700
        }
    }

    private fun collect(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)
        var count = 0
        while (stack.isNotEmpty() && count < 700 && sb.length < 9000) {
            val n = stack.removeAt(stack.size - 1)
            count++
            val t = n.text
            if (t != null) sb.append(t).append(' ')
            val d = n.contentDescription
            if (d != null) sb.append(d).append(' ')
            for (i in 0 until n.childCount) {
                val c = n.getChild(i)
                if (c != null) stack.add(c)
            }
        }
        return Guard.norm(sb.toString())
    }

    private fun toast(t: String) {
        main.post { Toast.makeText(applicationContext, t, Toast.LENGTH_SHORT).show() }
    }
}
